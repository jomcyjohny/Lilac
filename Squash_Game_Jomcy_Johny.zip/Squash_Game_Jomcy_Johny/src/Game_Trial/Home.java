package Game_Trial;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Home extends JFrame {
    public static void main(String[] args) {
        try {
            Home frame = new Home();
            frame.setVisible(true);
            JButton b= new JButton("Start");
            frame.add(b);
            b.setBounds(20,20,30,100);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Home() {
    	
        setBounds(100, 100, 450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
