package Game_Trial;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Ball {
	private static final int DIAMETER = 30;
	//ball variables for player one
	int x = 0;
	int y = 0;
	int xa = 1;
	int ya = 1;

	
	static int  p1 =0;
	static int p2 = 0;
	private Game game;

	public Ball(Game game) {
		this.game= game;
	}

	void move() {
		//ball1 bouncing
		if (y  < 0)
			ya = 1;
		
		if (y + xa> game.getHeight() - DIAMETER)
			ya = -1;
		
		if (x  < 0)
			xa = 1;
		
		if (x +DIAMETER> 1000)
			xa = -1;
				
		if (collisionp1()){
			xa = -xa;
			p1++;
		
		}
		if(collisionp2())
		{
			xa = -xa;
			p2++;
		}
		y = y + ya;
		x = x + xa;
		
	}

	private boolean collisionp1() {
		
		
		return game.racquet.getBounds().intersects(getBounds());
			
	}
private boolean collisionp2() {
	
		
		return game.racquet.getBoundsp2().intersects(getBounds());
			
	}
	
	public void paint(Graphics2D g) {
	
		g.setColor(Color.blue);
		g.drawString("Player 1: "+p1, 50, 30);
		g.setColor(Color.green);
		g.drawString("Player 2: "+p2, 625, 30);
		g.setColor(Color.yellow);
		g.fillOval(x, y, DIAMETER, DIAMETER);
		g.setColor(Color.red);
		if(p1>p2)
		{
			g.drawString("TOP SCORE", 50, 60);
		}
		else if(p2>p1)
		{
			g.drawString("TOP SCORE", 625, 60);
		}
		else if(p1 == p2 && p1!=0 &&p2!=0)
		{
			g.drawString("TIE", 625, 60);
			g.drawString("TIE", 50, 60);
		}
		else
		{
			g.drawString("START", 625, 60);
			g.drawString("START", 50, 60);
		}
		
	}
	
	public Rectangle getBounds() {
		return new Rectangle(x, y, DIAMETER, DIAMETER);
	}
	
}
