package Game_Trial;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class Racquet {
	private static final int X = 480;
	private static final int XX = 575;
	private static final int WIDTH = 10;
	private static final int HEIGHT = 90;
	int y = 0;
	int ya = 0;
	int yya = 0;
	int yy= 0;
	int x = 0;
	private Game game;

	public Racquet(Game game) {
		this.game = game;
		
	}

	public void move() {
		
		if (y + ya > 0 && y + ya < game.getHeight() - HEIGHT)
			y = y + ya;
		if(yy+yya>0 && yy+yya<game.getHeight() - HEIGHT)
			yy = yy + yya;
	
		
	}

	public void paint(Graphics2D g) {
		g.setColor(Color.BLACK);
		g.setColor(Color.BLUE);
		g.fillRect(X, y, WIDTH, HEIGHT);
		g.setColor(Color.green);
		g.fillRect(XX,yy , WIDTH, HEIGHT);
		
	}

	public void keyReleased(KeyEvent e) {
		ya = 0;
		yya=0;
	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP)
			ya = -2;
		if (e.getKeyCode() == KeyEvent.VK_DOWN)
			ya = 2;
		if (e.getKeyCode() == KeyEvent.VK_A)
			yya = -2;
		if (e.getKeyCode() == KeyEvent.VK_Z)
			yya = 2;
	}

	public Rectangle getBounds() {
		return new Rectangle(X, y, WIDTH, HEIGHT);
	}
	public Rectangle getBoundsp2() {
		return new Rectangle(XX, yy, WIDTH, HEIGHT);
	}
	public int getTopY() {
		return X;
	}
}