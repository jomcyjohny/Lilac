/*
 * Created by JFormDesigner on Sat Aug 27 18:11:47 IST 2016
 */

package Game_Trial;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * @author Jomcy Johny
 */
public class Index extends JPanel {
	public Index() {
		initComponents();
	}

	private void button1ActionPerformed(ActionEvent e) {
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setSize(1100, 700);
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Evaluation license - Jomcy Johny
		label3 = new JLabel();
		button1 = new JButton();
		button2 = new JButton();
		button3 = new JButton();

		//======== this ========
		setBackground(new Color(255, 153, 153));

		// JFormDesigner evaluation mark
		setBorder(new javax.swing.border.CompoundBorder(
			new javax.swing.border.TitledBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0),
				"JFormDesigner Evaluation", javax.swing.border.TitledBorder.CENTER,
				javax.swing.border.TitledBorder.BOTTOM, new java.awt.Font("Dialog", java.awt.Font.BOLD, 12),
				java.awt.Color.red), getBorder())); addPropertyChangeListener(new java.beans.PropertyChangeListener(){public void propertyChange(java.beans.PropertyChangeEvent e){if("border".equals(e.getPropertyName()))throw new RuntimeException();}});

		setLayout(null);

		//---- label3 ----
		label3.setText("2D SQUASH GAME");
		label3.setFont(new Font("Trajan Pro", Font.BOLD, 24));
		label3.setForeground(Color.white);
		add(label3);
		label3.setBounds(130, 15, 250, 84);

		//---- button1 ----
		button1.setText("Beginner");
		button1.setFont(new Font("Trajan Pro", Font.PLAIN, 14));
		button1.addActionListener(e -> button1ActionPerformed(e));
		add(button1);
		button1.setBounds(210, 115, 120, 33);

		//---- button2 ----
		button2.setText("Intermediate");
		button2.setFont(new Font("Trajan Pro", Font.PLAIN, 11));
		add(button2);
		button2.setBounds(210, 165, 120, 35);

		//---- button3 ----
		button3.setText("Expert");
		button3.setFont(new Font("Trajan Pro", Font.PLAIN, 14));
		add(button3);
		button3.setBounds(210, 215, 120, 35);

		{ // compute preferred size
			Dimension preferredSize = new Dimension();
			for(int i = 0; i < getComponentCount(); i++) {
				Rectangle bounds = getComponent(i).getBounds();
				preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
				preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
			}
			Insets insets = getInsets();
			preferredSize.width += insets.right;
			preferredSize.height += insets.bottom;
			setMinimumSize(preferredSize);
			setPreferredSize(preferredSize);
		}
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Evaluation license - Jomcy Johny
	private JLabel label3;
	private JButton button1;
	private JButton button2;
	private JButton button3;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
